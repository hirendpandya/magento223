<?php
namespace Ktpl\Grid\Logger;

class Logger extends \Monolog\Logger
{

}
